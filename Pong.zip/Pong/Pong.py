import pygame 
pygame.init()
win = pygame.display.set_mode((800, 800))
pygame.display.set_caption("Pong")
paddlex = 330
paddley = 750
ballx = 390
bally = 590
ballxvel = -3
ballyvel = -3
width = 80
height = 20
score = 0
paddlewidth = 200
paddleheight = 20
paddlevel = 0
paddlex2 = 350 + paddlewidth/2
paddley2 = 60 + paddleheight/2

balldirection = 0
run = True
while run:
    pygame.time.delay(15)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    if ballx > 780 or ballx < 20:
        ballxvel *= -1
    if bally > 800 or bally < 0:
        ballyvel *= -1
    if bally > 770 or bally < 30:
        if bally > 770:
            if ballx > paddlex and ballx < paddlex + paddlewidth:
                ballxvel = abs(ballxvel)
        if bally < 30:
            if ballx > paddlex2 and ballx < paddlex2 + paddlewidth:
                ballxvel = -abs(ballxvel)


    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and paddlex > paddlevel:
        paddlex -= 10
    if keys[pygame.K_RIGHT] and paddlex < 800 - paddlewidth - paddlevel:
        paddlex += 10
    win.fill((0, 0, 0))
    pygame.draw.rect(win, (255, 0, 0), (paddlex, paddley, paddlewidth, paddleheight))
    pygame.draw.rect(win, (0, 255, 0), (paddlex2, paddley2, paddlewidth, paddleheight))
    pygame.draw.ellipse(win, (255, 0, 255), (ballx, bally, width, height))
    if ballx > paddlex2 + paddlewidth/2:
        if paddlex2 < 800 - paddlewidth:
            paddlex2 += 3
    if ballx < paddlex2 + paddlewidth/2:
        if paddlex2 > 0:
            paddlex2 -= 3
    ballx += ballxvel
    bally += ballyvel
    pygame.display.update()